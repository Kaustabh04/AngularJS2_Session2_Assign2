
// Create a Class Vehicle
class Vehicle {
    constructor(name,type){
        this.name = name;
        this.type = type;
    }
    getName(){
        return this.name;
    }
    getType(){
        return this.type;
    }
}

let car = new Vehicle("Alto","Small-Car");

// Print Car name and type using Template literals
console.log(`The name of the car is ${car.name} and Type is a ${car.type}`);

// 1. Extending Class Vehicle
class Car extends Vehicle {
    constructor (name,type) {
        super(name, type,'car');
    }
    getName() {
        return 'It is a car: ' +
        super.getName();
    }
    getType(){
        return `The Type is: `+
        super.getType();
    }
}

let car1 = new Car("Fiat","Small Car");
console.log(car1.getName() + " " + car1.getType());

// 2. Extending Class
class Bike extends Vehicle{
    constructor(name){
        super(name,'bike');
    }
    getName(){
        return `This is a bike named ` +
        super.getName();
    }   
}

let bike = new Bike("Hero");
console.log(bike.getName());

// 3. Extending Class
class Cycle extends Vehicle{
    constructor(name){
        super(name,'cycle');
    }
    getName(){
        return `This is a cycle named ` +
        super.getName();
    }   
}

let cycle = new Cycle("BSA SLR");
console.log(cycle.getName());