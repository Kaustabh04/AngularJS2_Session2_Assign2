
// Creating Modules to be used for Calclation

// Add
export function add(x,y){
    return x + y;
}
// Substract
export function substract(x,y){
    return x - y;
}
// Multiply
export function multiply(x,y){
    return x * y;
}
// Square
export function square(x){
    return x * x;
}

// ========================================================= //

// Another way
function divide(a,b){
    return a / b;
}

function add1(a,b){
    return a + b;
}

export {divide, add1};