
// Importing module from another JS

// Importing Add and Substract functions
import {add,substract} from "calculations";

console.log(add(10,25));
console.log(substract(100,90));

// Importing the whole Module
import *as calculations from "calculations";

console.log(calculations.square(10));